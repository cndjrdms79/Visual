﻿
// pen88View.cpp: Cpen88View 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "pen88.h"
#endif

#include "pen88Doc.h"
#include "pen88View.h"
#include "CLine.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// Cpen88View

IMPLEMENT_DYNCREATE(Cpen88View, CView)

BEGIN_MESSAGE_MAP(Cpen88View, CView)
	// 표준 인쇄 명령입니다.
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_WM_MOUSEMOVE()
	ON_COMMAND(ID_SEL_COL, &Cpen88View::OnSelCol)
END_MESSAGE_MAP()

// Cpen88View 생성/소멸

Cpen88View::Cpen88View() noexcept
{
	// TODO: 여기에 생성 코드를 추가합니다.

}

Cpen88View::~Cpen88View()
{
}

BOOL Cpen88View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CView::PreCreateWindow(cs);
}

// Cpen88View 그리기
COLORREF col;
void Cpen88View::OnDraw(CDC* pDC)
{
	Cpen88Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: 여기에 원시 데이터에 대한 그리기 코드를 추가합니다.
	int n = pDoc->m_oa.GetSize();
	CLine* p;
	for (int i = 0; i < n; i++) {
		p = (CLine*)pDoc->m_oa[i];
		p->Draw(pDC);
	}

}


// Cpen88View 인쇄

BOOL Cpen88View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 기본적인 준비
	return DoPreparePrinting(pInfo);
}

void Cpen88View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄하기 전에 추가 초기화 작업을 추가합니다.
}

void Cpen88View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄 후 정리 작업을 추가합니다.
}


// Cpen88View 진단

#ifdef _DEBUG
void Cpen88View::AssertValid() const
{
	CView::AssertValid();
}

void Cpen88View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

Cpen88Doc* Cpen88View::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(Cpen88Doc)));
	return (Cpen88Doc*)m_pDocument;
}
#endif //_DEBUG


// Cpen88View 메시지 처리기

CPoint pnt;		//이전지점 현재지점 포인트 저장
void Cpen88View::OnMouseMove(UINT nFlags, CPoint point)
{
	if (nFlags == MK_LBUTTON) {
		CLine* p = new CLine(pnt, point, col);
		GetDocument()->m_oa.Add(p);
		Invalidate(false);
	}


	pnt = point;
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	CView::OnMouseMove(nFlags, point);
}


void Cpen88View::OnSelCol()
{
	CColorDialog dlg;
	if (dlg.DoModal() == IDOK) {
		col = dlg.GetColor();
	}

	// TODO: 여기에 명령 처리기 코드를 추가합니다.
}
